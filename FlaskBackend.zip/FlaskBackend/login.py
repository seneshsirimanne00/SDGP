import account , signUp


class Login:

    signUp = signUp.SignUp()

    def getAccount(self):
        return

    def getSignUp(self):
        return

    def authenticate(self):
        return