import signUp
import database

class main:

    def _getIntInput(self):
        return 0

    def _getStringInput(self):
        return "-string-"

    def login(self):
        return

    def signUp(self):
        return


    signUp.SignUp().emailvalidate()
