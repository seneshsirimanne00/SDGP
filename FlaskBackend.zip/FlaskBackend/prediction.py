class Prediction:

    __predictedSales = 0

    def __init__(self , salesData):
        self.salesData = salesData

    def getSalesData(self):
        return

    def train(self):
        return

    def predictNextMonth(self):
        return 