import product,stock


class Database:

    accounts = []
    products = []

    def __init__(self):
        print("-Database Object Created-")

    def getCredentials(self):
        print("-Some Credentials-")
        return

    def createNewFolder(self):
        return

    def load(self):
        return

    def save(self):
        return

    def getStock(self):
        return

    def getProduct(self):
        return

    def getProducts(self):
        return

    def addAccount(self , email , username , password):
        return